const Reg=require('../models/reg')
const bcrypt=require('bcrypt')



exports.loginpage=(req,res)=>{
    res.render('login.ejs',{message:''})
}
exports.registerpage=(req,res)=>{
    res.render('reg.ejs',{message:''})
}
exports.register= async(req,res)=>{
    const{us,pass}=req.body
    const usercheck=await Reg.findOne({username:us})
    const passconvert=await bcrypt.hash(pass,10)
    if(usercheck==null){
    const record=new Reg({username:us,password:passconvert})
    record.save()
    //console.log(record)
    res.render('reg.ejs',{message:`${us}  username successfully created`})
    }else{
           res.render('reg.ejs',{message:`${us}  username already regiserted with us`}) 
    }
}
exports.logincheck=async(req,res)=>{
   const{us,pass}=req.body
   const record=await Reg.findOne({username:us})
   if(record!==null){
   const passwordcompaare=await bcrypt.compare(pass,record.password)
   //console.log(passwordcompaare)
   if(passwordcompaare){
    req.session.isAuth=true
    req.session.loginname=us
    res.redirect('/parking')
   }else{
    res.render('login.ejs',{message:'wrong credenatils'})
   }
   }else{
    res.render('login.ejs',{message:'wrong credenatils'})
   }
}
exports.parkingpage=(req,res)=>{
    const loginname=req.session.loginname
    res.render('parking.ejs',{loginname})
}
exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/')
}